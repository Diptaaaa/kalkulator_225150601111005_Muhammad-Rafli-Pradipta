package com.example.kalkulator

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.TextView
import com.example.calculator.R

class MainActivity : AppCompatActivity() {

    private lateinit var resultTextView: TextView
    private var operand1: Double = 0.0
    private var operand2: Double = 0.0
    private var operation: String = ""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resultTextView = findViewById(R.id.resultTextView)

        val buttonClickListener = View.OnClickListener { v ->
            val button = v as Button
            resultTextView.append(button.text)
        }

        // Set OnClickListener for all number buttons
        findViewById<Button>(R.id.button0).setOnClickListener(buttonClickListener)
        findViewById<Button>(R.id.button1).setOnClickListener(buttonClickListener)
        findViewById<Button>(R.id.button2).setOnClickListener(buttonClickListener)
        findViewById<Button>(R.id.button3).setOnClickListener(buttonClickListener)
        findViewById<Button>(R.id.button4).setOnClickListener(buttonClickListener)
        findViewById<Button>(R.id.button5).setOnClickListener(buttonClickListener)
        findViewById<Button>(R.id.button6).setOnClickListener(buttonClickListener)
        findViewById<Button>(R.id.button7).setOnClickListener(buttonClickListener)
        findViewById<Button>(R.id.button8).setOnClickListener(buttonClickListener)
        findViewById<Button>(R.id.button9).setOnClickListener(buttonClickListener)

        // Set OnClickListener for operation buttons
        findViewById<Button>(R.id.buttonPlus).setOnClickListener {
            operation = "+"
            operand1 = resultTextView.text.toString().toDouble()
            resultTextView.text = ""
        }

        findViewById<Button>(R.id.buttonMinus).setOnClickListener {
            operation = "-"
            operand1 = resultTextView.text.toString().toDouble()
            resultTextView.text = ""
        }

        findViewById<Button>(R.id.buttonMultiply).setOnClickListener {
            operation = "*"
            operand1 = resultTextView.text.toString().toDouble()
            resultTextView.text = ""
        }

        findViewById<Button>(R.id.buttonDivide).setOnClickListener {
            operation = "/"
            operand1 = resultTextView.text.toString().toDouble()
            resultTextView.text = ""
        }

        findViewById<Button>(R.id.buttonEquals).setOnClickListener {
            operand2 = resultTextView.text.toString().toDouble()
            val result = when (operation) {
                "+" -> operand1 + operand2
                "-" -> operand1 - operand2
                "*" -> operand1 * operand2
                "/" -> operand1 / operand2
                else -> 0.0
            }
            resultTextView.text = result.toString()
        }

        findViewById<Button>(R.id.buttonClear).setOnClickListener {
            resultTextView.text = ""
            operand1 = 0.0
            operand2 = 0.0
            operation = ""
        }
    }
}
